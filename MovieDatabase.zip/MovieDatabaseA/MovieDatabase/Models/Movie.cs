﻿using System;
using System.Collections.Generic;

namespace MovieDatabase.Models
{

    public class Movie
    {
        // declare the movie properties and a constructor to initialise a blank movie

        Movie m = new Movie();

        public object Title { get; set; }
        public int Year { get; set; }
        public int Duration { get; set; }
    }

}
